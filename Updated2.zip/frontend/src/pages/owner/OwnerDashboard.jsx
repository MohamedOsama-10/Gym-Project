// src/pages/owner/OwnerDashboard.jsx
import React, { useState, Suspense, useEffect } from "react";
import { Routes, Route, useNavigate, useParams, Navigate } from "react-router-dom";
import Sidebar from "../../components/Sidebar";
import { ChatProvider } from "../../context/ChatContext";
import ChatNotificationBridge from "../../components/chat/ChatNotificationBridge";
import { useProfile } from "../../context/ProfileContext";
import NotificationCenter from "../../components/NotificationCenter";
import CoachDirectory from "../user/CoachDirectory";
import Memberships from "../user/Memberships";
import OwnerProfile from "./OwnerProfile";

// Lazy load modular components
const ChatPage = React.lazy(() => import("../../components/chat/ChatPage"));
const Branches = React.lazy(() => import("./components/Branches"));
const BranchHome = React.lazy(() => import("./components/BranchHome"));
const AdminManagement = React.lazy(() => import("./components/AdminManagement"));

// Safe Profile Avatar
function ProfileAvatar() {
  const { profile, loading, isReady } = useProfile();
  const navigate = useNavigate();
  if (loading || !isReady) return <div className="w-10 h-10 rounded-full bg-gray-200 animate-pulse" />;
  if (!profile) return <button onClick={() => navigate('/owner/profile')} className="w-10 h-10 rounded-full bg-gray-400 text-white font-bold">?</button>;
  const initials = profile.name?.split(' ').map(n => n[0]).join('').toUpperCase() || '?';
  return (
    <button onClick={() => navigate('/owner/profile')} className="relative group">
      <div className="w-10 h-10 rounded-full overflow-hidden ring-2 ring-orange-500/50">
        {profile.avatar ? <img src={profile.avatar} alt={profile.name} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-gradient-to-br from-orange-500 to-amber-600 flex items-center justify-center text-white text-sm font-bold">{initials}</div>}
      </div>
    </button>
  );
}

// Safe Welcome Header
function WelcomeHeader() {
  const { profile, loading, isReady } = useProfile();
  if (loading || !isReady) return <div className="h-6 w-48 bg-gray-200 rounded animate-pulse" />;
  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 dark:text-white">Welcome back, {profile?.name || 'Owner'}</h2>
      <p className="text-sm text-gray-500 dark:text-gray-400">Manage your gym branches</p>
    </div>
  );
}

// Coaches page wrapper
function CoachesPage() {
  const navigate = useNavigate();
  const { branchId } = useParams();
  return (
    <div className="space-y-6">
      <button onClick={() => navigate(`/owner/${branchId}`)} className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg">Back</button>
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="p-6 bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
          <h2 className="text-2xl font-bold">Coach Directory</h2>
          <p>Browse and manage coaches for this branch</p>
        </div>
        <div className="p-6"><CoachDirectory /></div>
      </div>
    </div>
  );
}

// Memberships page wrapper
function MembershipsPage() {
  const navigate = useNavigate();
  const { branchId } = useParams();
  return (
    <div className="space-y-6">
      <button onClick={() => navigate(`/owner/${branchId}`)} className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg">Back</button>
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="p-6 bg-gradient-to-r from-pink-600 to-rose-600 text-white">
          <h2 className="text-2xl font-bold">Memberships & Subscriptions</h2>
          <p>Owner Mode: You can edit gym subscriptions and view coach packages</p>
        </div>
        <div className="p-6"><Memberships userRole="owner" /></div>
      </div>
    </div>
  );
}

function DashboardContent() {
  const { profile, loading, isReady, error, refreshProfile } = useProfile();
  const [timeoutReached, setTimeoutReached] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (loading || !isReady) {
      const timer = setTimeout(() => setTimeoutReached(true), 10000);
      return () => clearTimeout(timer);
    }
  }, [loading, isReady]);

  if ((loading || !isReady) && !timeoutReached) return <div className="flex justify-center py-20 animate-spin">⌛</div>;
  if (timeoutReached || error || !profile) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold mb-4">Problem loading profile</h2>
        <button onClick={() => { setTimeoutReached(false); refreshProfile?.(); }} className="px-6 py-2 bg-orange-600 text-white rounded-lg mr-2">Retry</button>
        <button onClick={() => navigate('/login')} className="px-6 py-2 bg-gray-600 text-white rounded-lg">Login</button>
      </div>
    );
  }

  return (
    <Suspense fallback={<div className="flex justify-center py-20">Loading...</div>}>
      <Routes>
        <Route index element={<Branches />} />
        <Route path="profile" element={<OwnerProfile />} />
        <Route path=":branchId" element={<BranchHome />} />
        <Route path=":branchId/coaches" element={<CoachesPage />} />
        <Route path=":branchId/subscriptions" element={<MembershipsPage />} />
        <Route path=":branchId/admins" element={<AdminManagement />} />
        <Route path="chat" element={<ChatPage userRole="owner" />} />
        <Route path="*" element={<Navigate to="/owner" replace />} />
      </Routes>
    </Suspense>
  );
}

export default function OwnerDashboard() {
  return (
    <ChatProvider>
      <ChatNotificationBridge />
      <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
        <Sidebar />
        <div className="flex-1 flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
          <header className="flex items-center justify-between px-4 md:px-6 py-4 bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40">
            <WelcomeHeader />
            <div className="flex items-center gap-4">
              <NotificationCenter />
              <ProfileAvatar />
            </div>
          </header>
          <main className="flex-1 p-4 md:p-6 overflow-auto relative">
            <DashboardContent />
          </main>
        </div>
      </div>
    </ChatProvider>
  );
}
