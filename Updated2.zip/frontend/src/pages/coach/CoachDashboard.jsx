// src/pages/coach/CoachDashboard.jsx
import React, { Suspense, useState, useEffect, useRef } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Sidebar from "../../components/Sidebar";
import { ChatProvider } from "../../context/ChatContext";
import NotificationCenter from "../../components/NotificationCenter";
import ChatNotificationBridge from "../../components/chat/ChatNotificationBridge";
import coachAPI from "../../services/coachAPI";

// Lazy load components
const Users = React.lazy(() => import('./Users'));
const Bookings = React.lazy(() => import('./Bookings'));
const ChatPage = React.lazy(() => import('../../components/chat/ChatPage'));
const CoachProfile = React.lazy(() => import('./CoachProfile'));
const Programs = React.lazy(() => import('./Programs'));
const ProgramDetails = React.lazy(() => import('./ProgramDetails'));
const NewProgram = React.lazy(() => import('./NewProgram'));

const DashboardHome = React.lazy(() => import('./components/DashboardHome'));
const MyPackagesPage = React.lazy(() => import('./components/MyPackagesPage'));

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000/api/v1';
const API_ORIGIN = API_BASE_URL.replace('/api/v1', '');

// Helper functions for streak management
const getTodayKey = () => new Date().toISOString().split('T')[0];

const getStreakData = () => {
  const stored = localStorage.getItem('coachStreakData');
  if (stored) return JSON.parse(stored);
  return { streak: 0, lastLoginDate: null, loginDates: [] };
};

const saveStreakData = (data) => {
  localStorage.setItem('coachStreakData', JSON.stringify(data));
};

const calculateStreak = () => {
  const data = getStreakData();
  const today = getTodayKey();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayKey = yesterday.toISOString().split('T')[0];

  if (data.lastLoginDate === today) return data.streak;

  if (data.lastLoginDate === yesterdayKey || data.lastLoginDate === null) {
    const newStreak = data.streak + 1;
    const updatedData = {
      streak: newStreak,
      lastLoginDate: today,
      loginDates: [...data.loginDates, today]
    };
    saveStreakData(updatedData);
    return newStreak;
  }

  const updatedData = { streak: 1, lastLoginDate: today, loginDates: [today] };
  saveStreakData(updatedData);
  return 1;
};

// Loading fallback component
const DashboardFallback = () => (
  <div className="flex items-center justify-center h-screen">
    <div className="relative">
      <div className="w-20 h-20 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-4xl">💪</span>
      </div>
    </div>
  </div>
);

export default React.memo(function CoachDashboard() {
  const navigate = useNavigate();
  
  const [coachData, setCoachData] = useState({
    name: "Loading...",
    rating: 0,
    totalClients: 0,
    unreadMessages: 0,
    earningsThisMonth: 0,
    successRate: 0,
    isLoading: true,
    error: null
  });
  
  const [streak, setStreak] = useState(0);
  const [showStreakAnimation, setShowStreakAnimation] = useState(false);

  // Chat search state
  const [chatSearch, setChatSearch] = useState('');
  const [chatSearchResults, setChatSearchResults] = useState([]);
  const [showChatDropdown, setShowChatDropdown] = useState(false);
  const [chatSearchLoading, setChatSearchLoading] = useState(false);
  const chatSearchRef = useRef(null);
  const chatSearchTimeout = useRef(null);

  // Outside-click handler
  useEffect(() => {
    const handler = (e) => {
      if (chatSearchRef.current && !chatSearchRef.current.contains(e.target))
        setShowChatDropdown(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const profile = await coachAPI.getProfile();
        const bookings = await coachAPI.getBookings({ limit: 200 });

        const totalClients = profile.total_clients || 0;
        const completedSessions = bookings.filter(b => b.status === 'attended').length;
        const decidedSessions   = bookings.filter(b => ['attended','cancelled','missed'].includes(b.status)).length;
        const successRate = decidedSessions > 0 ? Math.round((completedSessions / decidedSessions) * 100) : 0;

        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);

        const monthlyCompleted = bookings.filter(b => {
          const bookingDate = new Date(b.session_date);
          return bookingDate >= startOfMonth && b.status === 'attended';
        });
        const earningsThisMonth = monthlyCompleted.reduce(
          (sum, b) => sum + (b.price || profile.hourly_rate || 0), 0
        );

        const activeThisMonth = new Set(
          bookings
            .filter(b => {
              const d = new Date(b.session_date);
              return d >= startOfMonth && ['confirmed', 'attended', 'upcoming'].includes(b.status);
            })
            .map(b => b.customer_id)
        ).size;

        let unreadMessages = 0;
        try {
          const token = localStorage.getItem('access_token');
          if (token) {
            const chatRes = await fetch(`${API_BASE_URL}/chat/conversations`, {
              headers: { Authorization: `Bearer ${token}` },
            });
            if (chatRes.ok) {
              const convs = await chatRes.json();
              unreadMessages = (convs || []).reduce((sum, c) => sum + (c.unreadCount || 0), 0);
            }
          }
        } catch (_) {}

        setCoachData({
          name: profile.name || profile.email,
          rating: profile.rating || 0,
          totalClients,
          activeThisMonth,
          unreadMessages,
          earningsThisMonth,
          successRate,
          isLoading: false,
          error: null,
          ...profile
        });
      } catch (error) {
        console.error("Failed to fetch dashboard data:", error);
        setCoachData(prev => ({ ...prev, isLoading: false, error: error.message }));
      }
    };

    fetchDashboardData();
    
    const prevData = getStreakData();
    const wasAlreadyToday = prevData.lastLoginDate === getTodayKey();
    const currentStreak = calculateStreak();
    setStreak(currentStreak);
    if (!wasAlreadyToday && currentStreak > 1) {
      setShowStreakAnimation(true);
      const timer = setTimeout(() => setShowStreakAnimation(false), 3000);
      return () => clearTimeout(timer);
    }
  }, []);

  const calculateProgress = (current, goal) => Math.min((current / goal) * 100, 100);

  const getProgressColor = (percentage) => {
    if (percentage < 50) return "from-red-500 to-red-600";
    if (percentage < 85) return "from-amber-500 to-orange-600";
    if (percentage <= 100) return "from-emerald-500 to-green-600";
    return "from-blue-500 to-indigo-600";
  };

  const getStreakMessage = (streakCount) => {
    if (streakCount === 1) return "First Day! 🎉";
    if (streakCount === 7) return "One Week! 🔥";
    if (streakCount === 30) return "One Month! 💪";
    if (streakCount === 100) return "Century! 🏆";
    if (streakCount >= 365) return "One Year! 🌟";
    return "Coaching Days";
  };

  if (coachData.isLoading) return <DashboardFallback />;

  if (coachData.error) {
    return (
      <div className="flex items-center justify-center h-screen text-red-600">
        <div className="text-center">
          <p className="text-xl font-bold mb-2">Error loading dashboard</p>
          <p>{coachData.error}</p>
          <button onClick={() => window.location.reload()} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg">Retry</button>
        </div>
      </div>
    );
  }

  const handleChatSearch = (q) => {
    setChatSearch(q);
    setShowChatDropdown(true);
    clearTimeout(chatSearchTimeout.current);
    if (!q.trim()) { setChatSearchResults([]); return; }
    setChatSearchLoading(true);
    chatSearchTimeout.current = setTimeout(async () => {
      try {
        const token = localStorage.getItem('access_token') || localStorage.getItem('token');
        const headers = { Authorization: `Bearer ${token}` };
        const [adminsRes, usersRes] = await Promise.all([
          fetch(`${API_BASE_URL}/admin/users/?role=admin&search=${encodeURIComponent(q)}`, { headers }),
          fetch(`${API_BASE_URL}/admin/users/?search=${encodeURIComponent(q)}`, { headers }),
        ]);
        const admins = adminsRes.ok ? await adminsRes.json() : [];
        const users  = usersRes.ok  ? await usersRes.json()  : [];
        const currentUser = (() => { try { return JSON.parse(localStorage.getItem('user') || '{}'); } catch { return {}; } })();
        const seen = new Set();
        const merged = [...(Array.isArray(admins) ? admins : []), ...(Array.isArray(users) ? users : [])]
          .filter(u => {
            if (u.id === currentUser.id) return false;
            if (seen.has(u.id)) return false;
            seen.add(u.id);
            return true;
          })
          .slice(0, 8)
          .map(u => ({
            id: u.id,
            name: u.full_name || u.email || '',
            email: u.email || '',
            role: u.role || 'user',
            avatarSrc: u.avatar_url ? (u.avatar_url.startsWith('http') ? u.avatar_url : `${API_ORIGIN}${u.avatar_url}`) : null,
          }));
        setChatSearchResults(merged);
      } catch { setChatSearchResults([]); }
      finally { setChatSearchLoading(false); }
    }, 300);
  };

  const openChatWith = (result) => {
    setChatSearch('');
    setChatSearchResults([]);
    setShowChatDropdown(false);
    navigate('/coach/chat', {
      state: { openUserId: result.id, openUserName: result.name, openUserAvatar: result.avatarSrc },
    });
  };

  return (
    <ChatProvider>
      <ChatNotificationBridge />
      <div className="flex min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-slate-900 dark:to-gray-900">
        <Sidebar />
        <div className="flex-1 pt-16 md:pt-0 flex flex-col min-h-screen">
          <header className="relative z-50 flex items-center justify-between px-4 md:px-6 py-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md shadow-sm border-b border-gray-200 dark:border-gray-700">
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Coach Dashboard</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">Welcome back, {coachData.name}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative hidden md:block" ref={chatSearchRef}>
                <input
                  type="text"
                  placeholder="Search admins, clients..."
                  value={chatSearch}
                  onChange={e => handleChatSearch(e.target.value)}
                  onFocus={() => chatSearch && setShowChatDropdown(true)}
                  className="w-56 pl-9 pr-4 py-2 bg-gray-100 dark:bg-gray-700 border-0 rounded-xl text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
                <svg className="w-4 h-4 text-gray-400 absolute left-2.5 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                {showChatDropdown && chatSearch.trim() && (
                  <div className="absolute top-full mt-2 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden z-50">
                    {chatSearchLoading ? (
                      <div className="flex items-center gap-2 px-4 py-3">
                        <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                        <p className="text-sm text-gray-500 dark:text-gray-400">Searching...</p>
                      </div>
                    ) : chatSearchResults.length === 0 ? (
                      <p className="text-sm text-gray-500 dark:text-gray-400 px-4 py-3">No users found</p>
                    ) : chatSearchResults.map(r => (
                      <button key={r.id} onClick={() => openChatWith(r)} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-left">
                        <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                          {r.avatarSrc ? <img src={r.avatarSrc} alt={r.name} className="w-full h-full object-cover" onError={e => { e.target.style.display='none'; e.target.parentNode.innerText=r.name.slice(0,2).toUpperCase(); }} /> : r.name.slice(0,2).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">{r.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{r.email}</p>
                        </div>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${r.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'} capitalize`}>{r.role}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <NotificationCenter />
              <button onClick={() => navigate('/coach/profile')} className="relative group">
                {coachData.avatar_url && <img src={coachData.avatar_url} alt={coachData.name} className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500" onError={e => e.target.style.display='none'} />}
                <div className={`w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full items-center justify-center text-white text-sm font-bold ${coachData.avatar_url ? 'hidden' : 'flex'}`}>
                  {coachData.name ? coachData.name.charAt(0).toUpperCase() : 'C'}
                </div>
              </button>
            </div>
          </header>

          <main className="flex-1 p-4 md:p-8 overflow-auto">
            <Suspense fallback={<DashboardFallback />}>
              <Routes>
                <Route index element={
                  <DashboardHome 
                    coachData={coachData} 
                    streak={streak} 
                    showStreakAnimation={showStreakAnimation}
                    calculateProgress={calculateProgress}
                    getProgressColor={getProgressColor}
                    getStreakMessage={getStreakMessage}
                  />
                } />
                <Route path="users" element={<Users coachData={coachData} />} />
                <Route path="bookings" element={<Bookings />} />
                <Route path="chat" element={<ChatPage userRole="coach" />} />
                <Route path="profile" element={<CoachProfile coachData={coachData} />} />
                <Route path="programs" element={<Programs />} />
                <Route path="programs/new" element={<NewProgram />} />
                <Route path="programs/:id" element={<ProgramDetails />} />
                <Route path="packages" element={<MyPackagesPage />} />
              </Routes>
            </Suspense>
          </main>
        </div>
      </div>
    </ChatProvider>
  );
});
