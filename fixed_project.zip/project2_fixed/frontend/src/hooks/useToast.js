// src/hooks/useToast.js
// Lightweight toast hook — drop-in replacement for alert().
// Uses the existing NotificationContext so no new UI component is needed.
//
// Usage:
//   const { toast } = useToast();
//   toast.success('Saved!');
//   toast.error('Failed: ' + err.message);
//   toast.info('Did you know...');

import { useCallback } from 'react';
import { useNotifications } from '../context/NotificationContext';

export function useToast() {
  const { addNotification } = useNotifications();

  const toast = {
    success: useCallback((message) => {
      addNotification({ type: 'success', title: 'Success', message });
    }, [addNotification]),

    error: useCallback((message) => {
      addNotification({ type: 'error', title: 'Error', message });
    }, [addNotification]),

    info: useCallback((message) => {
      addNotification({ type: 'info', title: 'Info', message });
    }, [addNotification]),
  };

  return { toast };
}
