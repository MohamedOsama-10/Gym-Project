// src/context/AuthContext.jsx - COMPLETE FIXED VERSION WITH FORMDATA SUPPORT
import { createContext, useState, useContext, useEffect, useCallback } from 'react';
import { apiRequest as httpClientRequest, API_CONFIG } from '../services/httpClient';

const AuthContext = createContext();

const getInitialAuthState = () => {
  if (typeof window === 'undefined') return { user: null, token: null };
  
  try {
    const storedUser = localStorage.getItem('user');
    const token = localStorage.getItem('access_token');
    
    if (storedUser && token) {
      const user = JSON.parse(storedUser);
      if (user && user.email && user.role) {
        return { user, token };
      }
    }
  } catch (error) {
    if (import.meta.env.DEV) { console.error('Error parsing auth state:', error); }
    localStorage.removeItem('user');
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
  }
  
  return { user: null, token: null };
};

// ✅ EXPORT useAuth here at the top level
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const initialState = getInitialAuthState();
  const [user, setUser] = useState(initialState.user);
  const [loading, setLoading] = useState(false);
  const [isReady, setIsReady] = useState(true);

  const API_BASE_URL = API_CONFIG.BASE_URL;

  useEffect(() => {
    if (import.meta.env.DEV) { console.log("🔐 Auth initialized:", {
      hasUser: !!initialState.user,
      userRole: initialState.user?.role,
      email: initialState.user?.email,
    }); }
    
    if (initialState.user && !user) {
      setUser(initialState.user);
    }
  }, []);

  // ✅ FIX: Define logout before apiRequest uses it
  // skipServerCall = true when triggered by a 401 (token already invalid/expired)
  const logout = useCallback(async (skipServerCall = false) => {
    setLoading(true);
    try {
      if (!skipServerCall) {
        const token = localStorage.getItem('access_token');
        const refreshToken = localStorage.getItem('refresh_token');

        if (token) {
          await fetch(`${API_BASE_URL}/auth/logout`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({ refresh_token: refreshToken }),
          }).catch(() => {});
        }
      }
    } catch (error) {
      if (import.meta.env.DEV) { console.error('Logout error:', error); }
    } finally {
      localStorage.removeItem('user');
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      localStorage.removeItem('ownerProfile'); // Clear profile to prevent data leaking between sessions
      setUser(null);
      setLoading(false);
      if (import.meta.env.DEV) { console.log("👋 Logged out"); }
    }
  }, []);

  // ── Silently refresh the access token using the refresh token ──────────────
  const refreshAccessToken = useCallback(async () => {
    const refreshToken = localStorage.getItem('refresh_token');
    if (!refreshToken) return null;
    try {
      const res = await fetch(`${API_BASE_URL}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: refreshToken }),
      });
      if (!res.ok) return null;
      const data = await res.json();
      if (data.access_token) {
        localStorage.setItem('access_token', data.access_token);
        if (data.refresh_token) localStorage.setItem('refresh_token', data.refresh_token);
        if (import.meta.env.DEV) { console.log('🔄 Access token refreshed silently'); }
        return data.access_token;
      }
      return null;
    } catch {
      return null;
    }
  }, []);

  // FIX: Delegate to the centralised httpClient.apiRequest instead of maintaining
  // a duplicate implementation. This ensures all authenticated requests share the
  // same token-refresh logic and FormData handling.
  // Kept as a useCallback so components that destructure apiRequest from useAuth()
  // don't need to be changed.
  const apiRequest = useCallback(
    (endpoint, options = {}) => httpClientRequest(endpoint, options),
    []
  );

  const signup = async (payload) => {
    setLoading(true);
    try {
      // FIX: use httpClientRequest — consistent error handling
      await httpClientRequest('/auth/signup', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      return await login(payload.email, payload.password, payload.role);
    } catch (error) {
      if (import.meta.env.DEV) { console.error('Signup error:', error); }
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password, role) => {
    setLoading(true);
    try {
      // FIX: use httpClientRequest — consistent error handling
      const data = await httpClientRequest('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password, role }),
      });
      if (import.meta.env.DEV) { console.log('✅ Login success:', data); }

      localStorage.setItem('access_token', data.access_token);
      if (data.refresh_token) {
        localStorage.setItem('refresh_token', data.refresh_token);
      }
      
      const userData = data.user || {
        id: data.id,
        full_name: data.full_name,
        email: data.email,
        role: data.role,
      };

      if (role && userData.role !== role) {
        throw new Error(`Incorrect role selected. Your account role is "${userData.role}".`);
      }

      localStorage.setItem('user', JSON.stringify(userData));
      setUser(userData);

      return userData;
    } catch (error) {
      if (import.meta.env.DEV) { console.error('Login error:', error); }
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const updateUser = useCallback((updates) => {
    setUser(prev => {
      const updated = { ...prev, ...updates };
      localStorage.setItem('user', JSON.stringify(updated));
      return updated;
    });
  }, []);

  const setSession = useCallback((accessToken, refreshToken, userData) => {
    localStorage.setItem('access_token', accessToken);
    if (refreshToken) localStorage.setItem('refresh_token', refreshToken);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
  }, []);

  const value = {
    user,
    login,
    signup,
    logout,
    updateUser,
    setSession,
    loading,
    isReady,
    isAuthenticated: !!user,
    apiRequest,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// ✅ Also export at the bottom as backup (optional but safe)
export default AuthContext;