// src/pages/coach/CoachDashboard.jsx
import React, { Suspense, useState, useEffect, useRef } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Sidebar from "../../components/Sidebar";
import { ChatProvider } from "../../context/ChatContext";
import NotificationCenter from "../../components/NotificationCenter";
import ChatNotificationBridge from "../../components/chat/ChatNotificationBridge";
import coachAPI from "../../services/coachAPI";
import { apiRequest, API_CONFIG } from "../../services/httpClient";
// FIX: Use shared useStreak hook (user-scoped) instead of inline hardcoded coachStreakData key
import { useStreak, getStreakMessage } from "../../hooks/useStreak";
import DashboardErrorBoundary from "../../components/DashboardErrorBoundary";
import PageSpinner from "../../components/PageSpinner";

const API_ORIGIN = API_CONFIG.ORIGIN;

const Users = React.lazy(() => import('./Users'));
const Bookings = React.lazy(() => import('./Bookings'));
const ChatPage = React.lazy(() => import('../../components/chat/ChatPage'));
const CoachProfile = React.lazy(() => import('./CoachProfile'));
const Programs = React.lazy(() => import('./Programs'));
const ProgramDetails = React.lazy(() => import('./ProgramDetails'));
const NewProgram = React.lazy(() => import('./NewProgram'));
const DashboardHome = React.lazy(() => import('./components/DashboardHome'));
const MyPackagesPage = React.lazy(() => import('./components/MyPackagesPage'));

export default React.memo(function CoachDashboard() {
  const navigate = useNavigate();

  const [coachData, setCoachData] = useState({
    name: "Loading...",
    rating: 0,
    totalClients: 0,
    unreadMessages: 0,
    earningsThisMonth: 0,
    successRate: 0,
    isLoading: true,
    error: null,
  });

  // FIX: coachData.id scopes the streak per user — no bleed between users on shared device
  const { streak, showStreakAnimation } = useStreak(coachData.id);

  const [chatSearch, setChatSearch] = useState('');
  const [chatSearchResults, setChatSearchResults] = useState([]);
  const [showChatDropdown, setShowChatDropdown] = useState(false);
  const [chatSearchLoading, setChatSearchLoading] = useState(false);
  const chatSearchRef = useRef(null);
  const chatSearchTimeout = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      if (chatSearchRef.current && !chatSearchRef.current.contains(e.target))
        setShowChatDropdown(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const profile = await coachAPI.getProfile();
        const bookings = await coachAPI.getBookings({ limit: 200 });

        const completedSessions = bookings.filter(b => b.status === 'attended').length;
        const decidedSessions = bookings.filter(b => ['attended', 'cancelled', 'missed'].includes(b.status)).length;
        const successRate = decidedSessions > 0 ? Math.round((completedSessions / decidedSessions) * 100) : 0;

        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);

        const earningsThisMonth = bookings
          .filter(b => new Date(b.session_date) >= startOfMonth && b.status === 'attended')
          .reduce((sum, b) => sum + (b.price || profile.hourly_rate || 0), 0);

        const activeThisMonth = new Set(
          bookings
            .filter(b => new Date(b.session_date) >= startOfMonth && ['confirmed', 'attended', 'upcoming'].includes(b.status))
            .map(b => b.customer_id)
        ).size;

        // FIX: httpClient.apiRequest handles 401 → refresh → retry automatically
        let unreadMessages = 0;
        try {
          const convs = await apiRequest('/chat/conversations');
          unreadMessages = (convs || []).reduce((sum, c) => sum + (c.unreadCount || 0), 0);
        } catch (_) {}

        setCoachData({
          name: profile.name || profile.email,
          rating: profile.rating || 0,
          totalClients: profile.total_clients || 0,
          activeThisMonth,
          unreadMessages,
          earningsThisMonth,
          successRate,
          isLoading: false,
          error: null,
          ...profile,
        });
      } catch (error) {
        setCoachData(prev => ({ ...prev, isLoading: false, error: error.message }));
      }
    };
    fetchDashboardData();
  }, []);

  const calculateProgress = (current, goal) => Math.min((current / goal) * 100, 100);
  const getProgressColor = (pct) => {
    if (pct < 50) return "from-red-500 to-red-600";
    if (pct < 85) return "from-amber-500 to-orange-600";
    if (pct <= 100) return "from-emerald-500 to-green-600";
    return "from-blue-500 to-indigo-600";
  };

  // FIX: httpClient.apiRequest instead of raw fetch — consistent auth + error handling
  const handleChatSearch = (q) => {
    setChatSearch(q);
    setShowChatDropdown(true);
    clearTimeout(chatSearchTimeout.current);
    if (!q.trim()) { setChatSearchResults([]); return; }
    setChatSearchLoading(true);
    chatSearchTimeout.current = setTimeout(async () => {
      try {
        const [admins, users] = await Promise.all([
          apiRequest(`/admin/users/?role=admin&search=${encodeURIComponent(q)}`).catch(() => []),
          apiRequest(`/admin/users/?search=${encodeURIComponent(q)}`).catch(() => []),
        ]);
        const seen = new Set();
        const merged = [...(Array.isArray(admins) ? admins : []), ...(Array.isArray(users) ? users : [])]
          .filter(u => { if (u.id === coachData.id || seen.has(u.id)) return false; seen.add(u.id); return true; })
          .slice(0, 8)
          .map(u => ({
            id: u.id,
            name: u.full_name || u.email || '',
            email: u.email || '',
            role: u.role || 'user',
            avatarSrc: u.avatar_url ? (u.avatar_url.startsWith('http') ? u.avatar_url : `${API_ORIGIN}${u.avatar_url}`) : null,
          }));
        setChatSearchResults(merged);
      } catch { setChatSearchResults([]); }
      finally { setChatSearchLoading(false); }
    }, 300);
  };

  const openChatWith = (result) => {
    setChatSearch(''); setChatSearchResults([]); setShowChatDropdown(false);
    navigate('/coach/chat', { state: { openUserId: result.id, openUserName: result.name, openUserAvatar: result.avatarSrc } });
  };

  if (coachData.isLoading) return <PageSpinner />;

  if (coachData.error) {
    return (
      <div className="flex items-center justify-center h-screen text-red-600">
        <div className="text-center">
          <p className="text-xl font-bold mb-2">Error loading dashboard</p>
          <p>{coachData.error}</p>
          <button onClick={() => window.location.reload()} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg">Retry</button>
        </div>
      </div>
    );
  }

  return (
    <ChatProvider>
      <ChatNotificationBridge />
      <div className="flex min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-slate-900 dark:to-gray-900">
        <Sidebar />
        <div className="flex-1 pt-16 md:pt-0 flex flex-col min-h-screen">
          <header className="relative z-50 flex items-center justify-between px-4 md:px-6 py-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md shadow-sm border-b border-gray-200 dark:border-gray-700">
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Coach Dashboard</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">Welcome back, {coachData.name}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative hidden md:block" ref={chatSearchRef}>
                <input type="text" placeholder="Search admins, clients..." value={chatSearch}
                  onChange={e => handleChatSearch(e.target.value)}
                  onFocus={() => chatSearch && setShowChatDropdown(true)}
                  className="w-56 pl-9 pr-4 py-2 bg-gray-100 dark:bg-gray-700 border-0 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none" />
                <svg className="w-4 h-4 text-gray-400 absolute left-2.5 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                {showChatDropdown && chatSearch.trim() && (
                  <div className="absolute top-full mt-2 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden z-50">
                    {chatSearchLoading ? (
                      <div className="flex items-center gap-2 px-4 py-3">
                        <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                        <p className="text-sm text-gray-500">Searching...</p>
                      </div>
                    ) : chatSearchResults.length === 0 ? (
                      <p className="text-sm text-gray-500 px-4 py-3">No users found</p>
                    ) : chatSearchResults.map(r => (
                      <button key={r.id} onClick={() => openChatWith(r)} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 text-left">
                        <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                          {r.avatarSrc ? <img src={r.avatarSrc} alt={r.name} className="w-full h-full object-cover" onError={e => { e.target.style.display = 'none'; e.target.parentNode.innerText = r.name.slice(0, 2).toUpperCase(); }} /> : r.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold truncate">{r.name}</p>
                          <p className="text-xs text-gray-500 truncate">{r.email}</p>
                        </div>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${r.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>{r.role}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <NotificationCenter />
              <button onClick={() => navigate('/coach/profile')}>
                {coachData.avatar_url && <img src={coachData.avatar_url} alt={coachData.name} className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500" onError={e => e.target.style.display = 'none'} />}
                <div className={`w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full items-center justify-center text-white text-sm font-bold ${coachData.avatar_url ? 'hidden' : 'flex'}`}>
                  {coachData.name ? coachData.name.charAt(0).toUpperCase() : 'C'}
                </div>
              </button>
            </div>
          </header>
          <main className="flex-1 p-4 md:p-8 overflow-auto">
            <DashboardErrorBoundary>
              <Suspense fallback={<PageSpinner />}>
                <Routes>
                  <Route index element={
                    <DashboardHome coachData={coachData} streak={streak} showStreakAnimation={showStreakAnimation}
                      calculateProgress={calculateProgress} getProgressColor={getProgressColor}
                      getStreakMessage={getStreakMessage} />
                  } />
                  <Route path="users" element={<Users coachData={coachData} />} />
                  <Route path="bookings" element={<Bookings />} />
                  <Route path="chat" element={<ChatPage userRole="coach" />} />
                  <Route path="profile" element={<CoachProfile coachData={coachData} />} />
                  <Route path="programs" element={<Programs />} />
                  <Route path="programs/new" element={<NewProgram />} />
                  <Route path="programs/:id" element={<ProgramDetails />} />
                  <Route path="packages" element={<MyPackagesPage />} />
                </Routes>
              </Suspense>
            </DashboardErrorBoundary>
          </main>
        </div>
      </div>
    </ChatProvider>
  );
});
