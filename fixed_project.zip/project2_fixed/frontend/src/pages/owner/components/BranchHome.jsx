// frontend/src/pages/owner/components/BranchHome.jsx
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Modal from "../../../components/Modal";
import { TotalMembersView, ActiveMembersView, RevenueView } from "../../../components/StatDetailViews";

import { apiRequest, API_CONFIG } from "../../../services/httpClient";
const API_ORIGIN = API_CONFIG.ORIGIN;

export default function BranchHome() {
  const { branchId } = useParams();
  const navigate = useNavigate();
  const [gym, setGym] = useState(null);
  const [stats, setStats] = useState({ totalMembers: 0, activeMembers: 0, totalCoaches: 0, todaysCheckins: 0, subscriptionsRevenue: 0 });
  const [loading, setLoading] = useState(true);
  const [activeModal, setActiveModal] = useState(null);

  useEffect(() => {
    setLoading(true);
    apiRequest(`/gyms/${branchId}`)
      .then(gymData => {
        setGym(gymData);
        setLoading(false);
        apiRequest(`/gyms/${branchId}/stats`)
          .then(statsData => setStats(statsData))
          .catch(() => {});
      })
      .catch(err => {
        console.error('Failed to load gym:', err);
        setLoading(false);
      });
  }, [branchId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="w-12 h-12 border-4 border-orange-200 border-t-orange-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!gym) {
    return (
      <div className="flex flex-col items-center justify-center h-96">
        <p className="text-xl text-gray-600 dark:text-gray-400 mb-4">Branch not found</p>
        <button onClick={() => navigate('/owner')} className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition">
          Back to Branches
        </button>
      </div>
    );
  }

  const imgSrc = gym.image_url
    ? (gym.image_url.startsWith('http') ? gym.image_url : `${API_ORIGIN}${gym.image_url}`)
    : 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&h=600&fit=crop';

  return (
    <div className="flex flex-col">
      <div className="relative h-64 rounded-2xl overflow-hidden mb-8">
        <img src={imgSrc} alt={gym.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex items-center">
          <div className="px-4 md:px-8">
            <h1 className="text-2xl md:text-4xl font-bold text-white mb-2">{gym.name}</h1>
            <p className="text-white/90 text-lg">{gym.location || ''}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <StatCard title="Total Members" value={stats.totalMembers} icon="👥" color="blue" clickable={true} onClick={() => setActiveModal('totalMembers')} />
        <StatCard title="Active Members" value={stats.activeMembers} icon="✅" color="green" clickable={true} onClick={() => setActiveModal('activeMembers')} />
        <StatCard title="Training Team" value={stats.totalCoaches} icon="💪" color="purple" clickable={true} onClick={() => navigate(`coaches`)} />
        <StatCard title="Today's Check-ins" value={stats.todaysCheckins} icon="📝" color="orange" clickable={false} />
        <StatCard title="Monthly Revenue" value={`${Number(stats.subscriptionsRevenue).toLocaleString()} EGP`} icon="💰" color="emerald" clickable={true} onClick={() => setActiveModal('revenue')} />
        <StatCard title="Memberships" value="View Plans" icon="🎫" color="pink" clickable={true} onClick={() => navigate(`subscriptions`)} />
      </div>

      <Modal isOpen={activeModal === 'totalMembers'} onClose={() => setActiveModal(null)} title="All Members Details" size="xl">
        <TotalMembersView gymId={branchId} />
      </Modal>
      <Modal isOpen={activeModal === 'activeMembers'} onClose={() => setActiveModal(null)} title="Active Members" size="lg">
        <ActiveMembersView gymId={branchId} />
      </Modal>
      <Modal isOpen={activeModal === 'revenue'} onClose={() => setActiveModal(null)} title="Financial Revenue Details" size="lg">
        <RevenueView gymId={branchId} revenue={stats.subscriptionsRevenue} />
      </Modal>
    </div>
  );
}
