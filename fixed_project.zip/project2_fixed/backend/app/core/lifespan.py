import asyncio
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI

logger = logging.getLogger(__name__)

async def cleanup_token_blacklist():
    """Periodic task to remove expired tokens from the blacklist."""
    from app.database import get_session_local
    from app.models.token_blacklist import TokenBlacklist
    from sqlalchemy import delete
    from datetime import datetime, timezone
    
    while True:
        try:
            SessionLocal = get_session_local()
            with SessionLocal() as db:
                stmt = delete(TokenBlacklist).where(TokenBlacklist.expires_at < datetime.now(timezone.utc))
                db.execute(stmt)
                db.commit()
                logger.info("Cleaned up expired blacklisted tokens")
        except Exception as e:
            logger.error(f"Error cleaning up token blacklist: {e}")
        
        await asyncio.sleep(3600)  # Run once every hour


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Create background task
    task = asyncio.create_task(cleanup_token_blacklist())
    yield
    # Shutdown: Cancel task
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        logger.info("Token blacklist cleanup task cancelled")
