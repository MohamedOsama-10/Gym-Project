from app.models.user import User
from app.models.customer import Customer
from app.models.coach import Coach



def test_signup_creates_coach_profile(client, db_session):
    """✅ Signup automatically creates coach profile"""
    response = client.post("/api/v1/auth/signup", json={
        "full_name": "Test Coach",
        "email": "coach@test.com",
        "password": "Password123!",
        "role": "coach"
    })
    
    assert response.status_code == 201
    user_id = response.json()["id"]
    
    # Check coach profile exists
    coach = db_session.query(Coach).filter(Coach.user_id == user_id).first()
    assert coach is not None
    assert coach.experience_years == 0  # Default value


def test_signup_creates_customer_profile(client, db_session):
    """✅ Signup automatically creates customer profile"""
    # Pre-create a user and a customer record with a membership_id
    pending_user = User(
        full_name="Placeholder",
        email="PENDING_MEM123_random@system.gym",
        password_hash="hash",
        role="user"
    )
    db_session.add(pending_user)
    db_session.commit()
    db_session.refresh(pending_user)
    
    customer = Customer(
        user_id=pending_user.id,
        membership_id="MEM123",
        notifications_enabled=True,
        email_updates_enabled=True,
        public_profile=False
    )
    db_session.add(customer)
    db_session.commit()

    response = client.post("/api/v1/auth/signup", json={
        "full_name": "Test Customer",
        "email": "customer@test.com",
        "password": "Password123!",
        "role": "user",
        "membership_id": "MEM123"
    })
    
    assert response.status_code == 201
    user_id = response.json()["id"]
    
    # Check customer profile exists
    customer = db_session.query(Customer).filter(Customer.user_id == user_id).first()
    assert customer is not None


def test_signup_success(client, db_session):
    response = client.post("/api/v1/auth/signup", json={
        "full_name": "Ahmed Coach",
        "email": "ahmed@example.com",
        "password": "Password123!",
        "role": "coach"
    })

    assert response.status_code == 201

    data = response.json()
    assert data["email"] == "ahmed@example.com"
    assert data["role"] == "coach"
    assert "password" not in data

    # ✅ User exists in DB
    user = db_session.query(User).filter_by(email="ahmed@example.com").first()
    assert user is not None

    # ✅ Coach profile auto-created
    coach = db_session.query(Coach).filter_by(user_id=user.id).first()
    assert coach is not None


def test_signup_duplicate_email(client, db_session):
    # Create first user
    client.post("/api/v1/auth/signup", json={
        "full_name": "John Doe",
        "email": "john@example.com",
        "password": "Password123!",
        "role": "coach"
    })

    # Try to create duplicate
    response = client.post("/api/v1/auth/signup", json={
        "full_name": "Jane Doe",
        "email": "john@example.com",
        "password": "Password456!",
        "role": "coach"
    })

    assert response.status_code == 400
    assert "already registered" in response.json()["detail"]


def test_refresh_token_works(client, db_session):
    """✅ Refresh token generates new access token"""
    # Create user first
    client.post("/api/v1/auth/signup", json={
        "full_name": "Test User",
        "email": "test@example.com",
        "password": "Password123!",
        "role": "coach"
    })

    # Login
    login_response = client.post("/api/v1/auth/login", json={
        "email": "test@example.com",
        "password": "Password123!"
    })
    
    refresh_token = login_response.json()["refresh_token"]
    
    # Use refresh token
    response = client.post(
        "/api/v1/auth/refresh",
        json={"refresh_token": refresh_token}
    )
    
    assert response.status_code == 200
    assert "access_token" in response.json()


def test_refresh_token_blacklisted_after_logout(client, db_session):
    """✅ Refresh token cannot be used after logout"""
    # Create user
    client.post("/api/v1/auth/signup", json={
        "full_name": "Test User",
        "email": "test@example.com",
        "password": "Password123!",
        "role": "coach"
    })

    # Login
    login_response = client.post("/api/v1/auth/login", json={
        "email": "test@example.com",
        "password": "Password123!"
    })
    
    access_token = login_response.json()["access_token"]
    refresh_token = login_response.json()["refresh_token"]
    
    # Logout
    client.post(
        "/api/v1/auth/logout",
        headers={"Authorization": f"Bearer {access_token}"},
        json={"refresh_token": refresh_token}
    )
    
    # Try to use refresh token
    response = client.post(
        "/api/v1/auth/refresh",
        json={"refresh_token": refresh_token}
    )
    
    assert response.status_code == 401
