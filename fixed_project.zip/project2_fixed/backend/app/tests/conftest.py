# app/tests/conftest.py
#
# Uses an in-memory SQLite database so tests never touch the real SQL Server.
# All fixtures that need a DB connection should use `db_session`.
# All fixtures that need an HTTP client should use `client` (not the module-level
# `TestClient(app)` pattern that bypasses the DB override).

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from app.main import app
from app.database import Base, get_db

# ── In-memory SQLite engine ───────────────────────────────────────────────
# `check_same_thread=False` is required because FastAPI can call get_db
# from a thread other than the one that created the engine.
SQLALCHEMY_DATABASE_URL = "sqlite://"  # pure in-memory, no file
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
)

# Enable FK enforcement in SQLite (off by default)
@event.listens_for(engine, "connect")
def set_sqlite_pragma(dbapi_conn, _):
    dbapi_conn.execute("PRAGMA foreign_keys=ON")

TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# ── Fixtures ──────────────────────────────────────────────────────────────

@pytest.fixture(scope="function")
def db_session():
    """
    Provides a clean SQLite session for each test.
    Tables are created before the test and dropped after, guaranteeing
    isolation even between parallel runs.
    """
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture(scope="function")
def client(db_session):
    """
    TestClient wired to the test DB via dependency_overrides.
    Use this in every test instead of the module-level TestClient(app),
    which bypasses the override and hits the real database.
    """
    def override_get_db():
        try:
            yield db_session
        finally:
            pass  # session lifecycle managed by db_session fixture

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


# ── Auth helpers ──────────────────────────────────────────────────────────
# Passwords must satisfy the complexity rule: 8+ chars, 1 uppercase, 1 digit, 1 special char.
TEST_PASSWORD = "TestPass1!"


@pytest.fixture
def owner_token(client):
    """Register and log in as OWNER; returns the access token."""
    client.post("/api/v1/auth/signup", json={
        "full_name": "Owner User",
        "email": "owner@test.com",
        "password": TEST_PASSWORD,
        "role": "owner",
    })
    resp = client.post("/api/v1/auth/login", json={
        "email": "owner@test.com",
        "password": TEST_PASSWORD,
    })
    assert resp.status_code == 200, f"Owner login failed: {resp.text}"
    return resp.json()["access_token"]


@pytest.fixture
def coach_token(client, db_session):
    """Register and log in as COACH; also creates the coach profile row."""
    from app.models.coach import Coach
    resp = client.post("/api/v1/auth/signup", json={
        "full_name": "Coach User",
        "email": "coach@test.com",
        "password": TEST_PASSWORD,
        "role": "coach",
    })
    assert resp.status_code == 201, f"Coach signup failed: {resp.text}"
    user_id = resp.json()["id"]

    # Ensure coach profile exists (signup should create it; belt-and-suspenders)
    if not db_session.query(Coach).filter(Coach.user_id == user_id).first():
        db_session.add(Coach(user_id=user_id, experience_years=5, hourly_rate=50.0))
        db_session.commit()

    resp = client.post("/api/v1/auth/login", json={
        "email": "coach@test.com",
        "password": TEST_PASSWORD,
    })
    assert resp.status_code == 200, f"Coach login failed: {resp.text}"
    return resp.json()["access_token"]


@pytest.fixture
def customer_token(client, db_session):
    """Register and log in as CUSTOMER; also creates the customer profile row."""
    from app.models.customer import Customer
    resp = client.post("/api/v1/auth/signup", json={
        "full_name": "Customer User",
        "email": "customer@test.com",
        "password": TEST_PASSWORD,
        "role": "user",
        "membership_id": "TEST001",   # adjust if your signup flow requires one
    })
    # Accept 201 (success) or 400 (already claimed) for re-runs
    user_id = resp.json().get("id")
    if user_id and not db_session.query(Customer).filter(Customer.user_id == user_id).first():
        db_session.add(Customer(user_id=user_id, height=175.0, weight=70.0))
        db_session.commit()

    resp = client.post("/api/v1/auth/login", json={
        "email": "customer@test.com",
        "password": TEST_PASSWORD,
    })
    assert resp.status_code == 200, f"Customer login failed: {resp.text}"
    return resp.json()["access_token"]
