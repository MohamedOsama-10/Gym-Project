# app/main.py
import os
import asyncio
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from sqlalchemy import text

from app.api.v1 import (
    auth, availability, bookings, profile, gyms, subscriptions,
    admin_owner, admin, workouts, reviews, meals, memberships,
    coach, training_programs, chat, coach_trainees, admin_profile,
    coach_packages, notifications, users,
)
from app.database import Base
from app.config import settings
from app.core.lifespan import lifespan

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

limiter = Limiter(key_func=get_remote_address, enabled=os.environ.get("RATELIMIT_ENABLED", "True") == "True")
app = FastAPI(
    title="Gym Management API",
    version="1.0.0",
    description="Backend for gym management system",
    lifespan=lifespan,
)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
    allow_headers=["Content-Type", "Authorization", "X-Requested-With"],
)

# ── Static files ───────────────────────────────────────────────────────────────
uploads_dir = "uploads"
os.makedirs(os.path.join(uploads_dir, "avatars"), exist_ok=True)
os.makedirs(os.path.join(uploads_dir, "chat"), exist_ok=True)
app.mount("/uploads", StaticFiles(directory=uploads_dir), name="uploads")


# ── Register all routers ──────────────────────────────────────────────────────
app.include_router(auth.router,             prefix="/api/v1")
app.include_router(users.router,            prefix="/api/v1")
app.include_router(availability.router,     prefix="/api/v1")
app.include_router(bookings.router,         prefix="/api/v1")
app.include_router(profile.router,          prefix="/api/v1")
app.include_router(gyms.router,             prefix="/api/v1")
app.include_router(subscriptions.router,    prefix="/api/v1")
app.include_router(admin_owner.router,      prefix="/api/v1")
app.include_router(admin.router,            prefix="/api/v1")
app.include_router(workouts.router,         prefix="/api/v1")
app.include_router(meals.router,            prefix="/api/v1")
app.include_router(chat.router,             prefix="/api/v1")
app.include_router(reviews.router,          prefix="/api/v1")
app.include_router(memberships.router,      prefix="/api/v1")
app.include_router(coach.router,            prefix="/api/v1")
app.include_router(training_programs.router,prefix="/api/v1")
app.include_router(coach_trainees.router,   prefix="/api/v1")
app.include_router(admin_profile.router,    prefix="/api/v1")
app.include_router(coach_packages.router,   prefix="/api/v1")
app.include_router(notifications.router,    prefix="/api/v1")


# ── Global exception handler ───────────────────────────────────────────────────
@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    import traceback
    logger.error(f"Unhandled exception: {exc}\n{traceback.format_exc()}")
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


# ── Routes ───────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {"message": "Gym Management API is running"}


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "version": "1.0.0",
        "environment": os.environ.get("RAILWAY_ENVIRONMENT", "local"),
        "database": f"{settings.DB_SERVER}/{settings.DB_NAME}",
    }


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port)
